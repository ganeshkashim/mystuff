# Azure-ServiceBus-Queue
Azure Service Bus - Queue

https://www.c-sharpcorner.com/article/azure-service-bus-queue-with-real-world-scenario/
